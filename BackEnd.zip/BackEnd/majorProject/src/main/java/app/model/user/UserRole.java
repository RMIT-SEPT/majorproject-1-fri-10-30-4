package app.model.user;

public enum UserRole {

	NULL, CUSTOMER, EMPLOYEE, BUSINESS_ADMIN
	
}